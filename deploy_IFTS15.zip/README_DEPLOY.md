# Deploy incremental IFTS15

Este paquete contiene solo los archivos modificados para subir al hosting de InfinityFree.

## Archivos a subir

Subir cada archivo respetando la misma ruta dentro de public_html.

- .htaccess
- src/Controllers/viewController.php
- src/Controllers/bolsaTrabajoController.php
- src/Template/sidebar.php
- src/config.php
- src/Model/BolsaTrabajo.php
- src/Model/PostulacionBolsaTrabajo.php
- src/Views/bolsa-trabajo.php
- src/services/CloudinaryService.php
- src/services/MailerService.php

## Migraciones a ejecutar

Ejecutar en la base de datos de produccion, en este orden:

1. src/ConectionBD/migrations/20260525_bolsa_trabajo.sql
2. src/ConectionBD/migrations/20260525_bolsa_trabajo_postulaciones.sql

## Variables de entorno a revisar en produccion

- BASE_URL=https://tu-dominio.infinityfreeapp.com
- DB_HOST
- DB_PORT
- DB_NAME
- DB_USERNAME
- DB_PASSWORD
- MAIL_HOST
- MAIL_PORT
- MAIL_USERNAME
- MAIL_PASSWORD
- MAIL_ENCRYPTION
- MAIL_FROM_ADDRESS
- MAIL_FROM_NAME=IFTS15
- ADMIN_EMAIL o ADMIN_EMAILS
- CLOUDINARY_CLOUD_NAME
- CLOUDINARY_API_KEY
- CLOUDINARY_API_SECRET

## Verificacion minima post deploy

1. Abrir la vista de bolsa de trabajo.
2. Verificar que roles 3 y 5 puedan crear y gestionar ofertas.
3. Verificar que un alumno vea ofertas publicadas.
4. Verificar postulación con CV.
5. Verificar correo de confirmación al alumno.

## Nota

No subir el archivo .env local. Usar la plantilla env.production.example y completar con credenciales reales del hosting.